let value1el = document.getElementById("first-value");
let unit1el = document.getElementById("first-unit");
let value2el = document.getElementById("second-value");
let unit2el = document.getElementById("second-unit");
let btnel = document.getElementById("convert-btn");
let iconbtn = document.getElementById("icon")

const convertvalue = () => {
    let value1 = value1el.value;
    let unit1 = unit1el.value;
    let unit2 = unit2el.value;

    let value1inlegalunit;
    let convertedvalue;

    switch(unit1) {
        case ("km") :
            value1inlegalunit = value1 * 1000;
            break;
        
        case ("cm") :
            value1inlegalunit = value1 / 100;
            break;

        case ("mm") :
                value1inlegalunit = value1 / 1000;
            break;
        default :
            value1inlegalunit = value1;
        
    }

    switch(unit2) {
        case ("km"):
            convertedvalue = value1inlegalunit / 1000;
            break;

        case("m"):
            convertedvalue = value1inlegalunit;
            break;

        case("mm"):
            convertedvalue = value1inlegalunit * 1000;
            break;

        default:
            convertedvalue = value1inlegalunit *100;
    }

    value2el.value = convertedvalue;
};


btnel.addEventListener( 'click' , convertvalue );
iconbtn.addEventListener('click' , convertvalue);
unit2el.addEventListener ( 'change' , () => {
    value2el.value = "";
});